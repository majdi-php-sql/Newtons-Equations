<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $initialVelocity = $_POST['initial_velocity'];
    $acceleration = $_POST['acceleration'];
    $time = $_POST['time'];

    $finalVelocity = $initialVelocity + ($acceleration * $time);
    $displacement = ($initialVelocity * $time) + (0.5 * $acceleration * pow($time, 2));

    echo json_encode([
        'final_velocity' => number_format($finalVelocity, 2),
        'displacement' => number_format($displacement, 2),
    ]);
}
?>
