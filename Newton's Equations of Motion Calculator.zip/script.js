function calculate() {
    const initialVelocity = parseFloat(document.getElementById('initial_velocity').value);
    const acceleration = parseFloat(document.getElementById('acceleration').value);
    const time = parseFloat(document.getElementById('time').value);

    fetch('calculate.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `initial_velocity=${initialVelocity}&acceleration=${acceleration}&time=${time}`,
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('final_velocity').textContent = data.final_velocity;
        document.getElementById('displacement').textContent = data.displacement;
    })
    .catch(error => console.error(error));
}
